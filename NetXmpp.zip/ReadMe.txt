As agreed this is XMPP implementation as command line tool.
Covered Api implementations are:
*connect/disconnect
*set presense 
*get roster
*authorize
-no encryption
